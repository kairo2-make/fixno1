document.addEventListener('DOMContentLoaded', function() {
    // Check if prefers-reduced-motion is enabled
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    
    if (!prefersReducedMotion) {
      // Set up scroll event listener with requestAnimationFrame
      let ticking = false;
      
      window.addEventListener('scroll', function() {
        if (!ticking) {
          window.requestAnimationFrame(function() {
            updateParallax();
            ticking = false;
          });
          ticking = true;
        }
      });
      
      // Initialize elements
      document.querySelectorAll('[data-parallax-speed]').forEach(el => {
        el.style.transform = 'translateY(0)';
      });
      
      // Run once on load
      updateParallax();
    }
    
    function updateParallax() {
      const scrollPosition = window.pageYOffset;
      const aboutSection = document.querySelector('.about_section');
      const sectionTop = aboutSection.offsetTop;
      const sectionHeight = aboutSection.offsetHeight;
      const viewportHeight = window.innerHeight;
      
      // Calculate section visibility (0 when top at bottom of viewport, 1 when bottom at top of viewport)
      const sectionStart = scrollPosition + viewportHeight - sectionTop;
      const sectionEnd = scrollPosition - (sectionTop + sectionHeight);
      const sectionVisibility = Math.min(1, Math.max(0, sectionStart / (viewportHeight + sectionHeight)));
      
      // Apply parallax effects
      document.querySelectorAll('[data-parallax-speed]').forEach(el => {
        const speed = parseFloat(el.getAttribute('data-parallax-speed'));
        const movement = sectionVisibility * 100 * speed;
        
        if(el.classList.contains('parallax-img')) {
          // Image moves up (reveals more of the image)
          el.style.transform = `translateY(-${movement * 0.6}px) scale(${1 + sectionVisibility * 0.05})`;
        } else {
          // Other elements move down
          el.style.transform = `translateY(${movement}px)`;
        }
      });
    }
  });